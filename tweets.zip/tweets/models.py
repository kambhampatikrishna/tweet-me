from django.db import models
from django.conf import settings
# Create your models here.
class Tweet(models.Model):
    user        =models.ForeignKey('auth.User', related_name='tweetme', on_delete= models.CASCADE)
    content      =models.CharField(max_length=150)
    updated     =models.DateTimeField(auto_now=True)
    timestamp   =models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return str(self.id)
        